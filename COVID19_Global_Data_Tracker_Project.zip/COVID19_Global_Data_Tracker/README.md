# COVID-19 Global Data Tracker

## Project Description
This project analyzes global COVID-19 trends using real-world data. It covers cases, deaths, and vaccinations across different countries and time periods.

## Objectives
- Import and clean COVID-19 global data
- Analyze time trends (cases, deaths, vaccinations)
- Compare metrics across countries/regions
- Visualize trends with charts and maps
- Communicate findings in a Jupyter Notebook report

## Tools & Libraries
- Python
- pandas
- matplotlib
- seaborn
- plotly (optional for choropleth maps)
- Jupyter Notebook

## How to Run
1. Open the Jupyter Notebook `COVID19_Global_Data_Tracker.ipynb`
2. Run each cell in order to execute the analysis

## Insights
- Countries like the USA and India reported the highest total cases.
- Vaccination rates varied significantly by region.
- Some countries achieved rapid vaccine rollouts early in 2021.
